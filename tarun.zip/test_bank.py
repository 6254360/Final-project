import unittest
from bank import BankAccount

class TestBankAccount(unittest.TestCase):
    def setUp(self):
        # Create two bank accounts for testing
        self.account1 = BankAccount("John Doe", 1000)
        self.account2 = BankAccount("Jane Smith", 500)

    def test_deposit(self):
        self.assertTrue(self.account1.deposit(500))
        self.assertTrue(self.account2.deposit(100))
        self.assertFalse(self.account1.deposit(-200))

    def test_withdraw(self):
        self.assertTrue(self.account1.withdraw(300))
        self.assertTrue(self.account2.withdraw(200))
        self.assertFalse(self.account1.withdraw(2000))
        self.assertFalse(self.account2.withdraw(-100))

    def test_get_balance(self):
        self.assertEqual(self.account1.get_balance(), 1000)
        self.assertEqual(self.account2.get_balance(), 500)

    def test_transfer(self):
        self.assertTrue(self.account1.transfer(self.account2, 300))
        self.assertEqual(self.account1.get_balance(), 700)
        self.assertEqual(self.account2.get_balance(), 800)
        self.assertFalse(self.account1.transfer(self.account2, 1000))
        self.assertFalse(self.account2.transfer(self.account1, -200))

    def test_statement(self):
        statement1 = "Account Holder: John Doe, Balance: 1000\nTransaction History:"
        # Add the expected transaction history to the statement
        expected_statement1 = statement1 + "\n"
        self.assertEqual(self.account1.statement(), expected_statement1)


    def test_add_interest(self):
        self.account1.add_interest(2.5)
        self.assertEqual(self.account1.get_balance(), 1025.0)

    def test_close_account(self):
        self.account1.close_account()
        self.assertEqual(self.account1.get_balance(), 0)

    def test_set_balance(self):
        self.account1.set_balance(1500)
        self.assertEqual(self.account1.get_balance(), 1500)

    def test_get_transaction_history(self):
        self.account1.deposit(500)
        self.account1.withdraw(200)
        self.assertEqual(len(self.account1.get_transaction_history()), 2)

    def test_is_balance_negative(self):
        self.account1.set_balance(-200)  # Set a negative balance for testing
        self.assertTrue(self.account1.is_balance_negative())


    def test_is_balance_positive(self):
        self.assertTrue(self.account1.is_balance_positive())

    def test_is_balance_zero(self):
        self.assertFalse(self.account1.is_balance_zero())
        self.account1.set_balance(0)
        self.assertTrue(self.account1.is_balance_zero())

    def test_has_negative_transaction(self):
        self.assertFalse(self.account1.has_negative_transaction())

    def test_has_positive_transaction(self):
        self.assertFalse(self.account1.has_positive_transaction())
        self.account1.deposit(500)
        self.assertTrue(self.account1.has_positive_transaction())

    def test_has_deposit_transaction(self):
        self.assertFalse(self.account1.has_deposit_transaction())
        self.account1.deposit(500)
        self.assertTrue(self.account1.has_deposit_transaction())

    def test_has_withdraw_transaction(self):
        self.assertFalse(self.account1.has_withdraw_transaction())
        self.account1.withdraw(200)
        self.assertTrue(self.account1.has_withdraw_transaction())

    def test_get_total_deposits(self):
        self.account1.deposit(500)
        self.account1.deposit(200)
        self.assertEqual(self.account1.get_total_deposits(), 700)

    def test_get_total_withdrawals(self):
        self.account1.withdraw(200)
        self.account1.withdraw(100)
        self.assertEqual(self.account1.get_total_withdrawals(), 300)

    def test_is_account_closed(self):
        self.assertFalse(self.account1.is_account_closed())
        self.account1.close_account()
        self.assertTrue(self.account1.is_account_closed())

    def test_get_last_transaction(self):
        self.assertEqual(self.account1.get_last_transaction(), "No transactions found.")
        self.account1.deposit(500)
        self.assertEqual(self.account1.get_last_transaction(), "Deposit: +$500")

    def test_is_transaction_in_history(self):
        self.assertFalse(self.account1.is_transaction_in_history("Withdraw: -$200"))
        self.account1.withdraw(200)
        self.assertTrue(self.account1.is_transaction_in_history("Withdraw: -$200"))

    def test_reverse_last_transaction(self):
        self.assertEqual(self.account1.reverse_last_transaction(), "No transactions to reverse.")
        self.account1.deposit(500)
        self.assertEqual(self.account1.reverse_last_transaction(), "Reversed Deposit: -$500")
        self.assertEqual(self.account1.get_balance(), 1000)

if __name__ == "__main__":
    unittest.main()
